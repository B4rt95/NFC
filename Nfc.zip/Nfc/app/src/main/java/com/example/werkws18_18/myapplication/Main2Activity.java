package com.example.werkws18_18.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        final TextView txt_view = findViewById(R.id.textView2);
        Intent aufruf = getIntent();
        String intentText = "";
        if (aufruf.getExtras() != null) {
            intentText = aufruf.getExtras().get("NEXTACTIVITY").toString();
            txt_view.setText(intentText);
        }
    }
}
