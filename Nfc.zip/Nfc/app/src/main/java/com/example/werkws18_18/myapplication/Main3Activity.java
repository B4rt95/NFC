package com.example.werkws18_18.myapplication;

import android.content.Context;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends NfcActivity {


    @Override
    public void nfcRead(Intent intent) {
        Log.i("Test", "beginne die methode");
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        byte[] tagID = tag.getId();
        String tagIdString = byteArrayToHex(tagID);
        /*final TextView txt_view = findViewById(R.id.textView);
        txt_view.setText(txt_view.getText().toString() + "Name");*/
        Context context = getApplicationContext();
        CharSequence text = tagIdString;
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


    public static String byteArrayToHex(byte[] a) {
        StringBuilder sb = new StringBuilder(a.length * 2);
        for(byte b: a)
            sb.append(String.format("%02x",b & 0xff));
        return sb.toString();
    }



}
